Most Complete Amiibo Set (MCAS)

MCAS is a preservation project containing clean binary dumps of the NTAG215 (and other NFC tag types) found inside official Nintendo amiibo figures, cards, plushes, and related products.

All dumps are direct retail reads. They remain encrypted, contain no user save data, and were usually captured immediately after opening the packaging to ensure clean, authentic archives.

The set also includes the key files needed for decrypting or encrypting amiibo bins with compatible tools.

MCAS is primarily hosted on Archive.org for long-term preservation.
Please support official amiibo releases.

Latest MCAS uploads can be found here:
https://archive.org/search?query=Most+Complete+Amiibo+Set&sort=-publicdate&and%5B%5D=subject%3A%22nfc%22&and%5B%5D=subject%3A%22amiibo%22

Special thanks to everyone who has contributed to this project.